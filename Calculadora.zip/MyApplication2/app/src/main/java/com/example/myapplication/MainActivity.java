package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MainActivity extends AppCompatActivity {
    TextView tvScreen;
    private TextView textViewPantalla;
    private String valorActual = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewPantalla = findViewById(R.id.tvScreen);
        actualizarPantalla();
    }

    private void actualizarPantalla() {
        textViewPantalla.setText(valorActual);
    }

    public void escribirNumero(View view) {
        String numero = ((TextView) view).getText().toString();
        if (valorActual.equals("0")) {
            valorActual = numero;
        } else {
            valorActual += numero;
        }
        actualizarPantalla();
    }

    public void escribirOperador(View view) {
        String operador = ((TextView) view).getText().toString();
        valorActual += operador;
        actualizarPantalla();
    }

    public void calcular(View view) {
        String[] partes = valorActual.split("[-+*/]");
        BigDecimal resultado = realizarCalculo(new BigDecimal(partes[0]), new BigDecimal(partes[1]), obtenerOperador(valorActual));
        valorActual = resultado.toString();
        actualizarPantalla();
    }

    private BigDecimal realizarCalculo(BigDecimal numero1, BigDecimal numero2, String operador) {
        BigDecimal resultado = new BigDecimal("0");
        switch (operador) {
            case "+":
                resultado = numero1.add(numero2);
                break;
            case "-":
                resultado = numero1.subtract(numero2);
                break;
            case "*":
                resultado = numero1.multiply(numero2);
                break;
            case "/":
                if (numero2.compareTo(BigDecimal.ZERO) != 0) {
                    resultado = numero1.divide(numero2, RoundingMode.HALF_UP);
                } else {
                    Toast.makeText(this, "No se puede dividir por cero", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        return resultado;
    }

    private String obtenerOperador(String expresion) {
        String operadores = "+-*/";
        for (char caracter : expresion.toCharArray()) {
            if (operadores.contains(String.valueOf(caracter))) {
                return String.valueOf(caracter);
            }
        }
        return "";
    }

    public void limpiar(View view) {
        valorActual = "0";
        actualizarPantalla();
    }

    public void borrar(View view) {
        if (valorActual.length() > 0) {
            valorActual = valorActual.substring(0, valorActual.length() - 1);
        }
        if (valorActual.isEmpty()) {
            valorActual = "0";
        }
        actualizarPantalla();
    }
}

